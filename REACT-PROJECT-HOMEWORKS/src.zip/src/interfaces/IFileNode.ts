export interface IFileNode {
  id: string
  name: string
  type: "folder" | "file"
  createdBy: string
  children: IFileNode[]
}
import type { IFileNode } from "../../interfaces/IFileNode"

interface FileTreeViewProps {
  node: IFileNode
}

function TreeItem({ node }: FileTreeViewProps) {
  return (
    <li className="tree-node">
      <div className={`tree-item ${node.type}`}>
        <span className="tree-icon">{node.type === "folder" ? "📁" : "📄"}</span>

        <div className="tree-info">
          <p>{node.name}</p>
          <small>Creado por: {node.createdBy}</small>
        </div>
      </div>

      {node.children.length > 0 && (
        <ul className="tree-children">
          {node.children.map(child => (
            <TreeItem key={child.id} node={child} />
          ))}
        </ul>
      )}
    </li>
  )
}

export default function FileTreeView({ node }: FileTreeViewProps) {
  return (
    <section className="panel-card">
      <h2>Estructura</h2>

      <ul className="tree-root">
        <TreeItem node={node} />
      </ul>
    </section>
  )
}
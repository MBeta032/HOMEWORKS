import type { IFileNode } from "../interfaces/IFileNode"

export class FileTree {
  root: IFileNode

  constructor(root?: IFileNode) {
    this.root = root || {
      id: "root",
      name: "Mi unidad",
      type: "folder",
      createdBy: "system",
      children: [],
    }
  }

  getRoot() {
    return this.root
  }

  findNodeById(id: string, currentNode: IFileNode = this.root): IFileNode | null {
    if (currentNode.id === id) {
      return currentNode
    }

    for (const child of currentNode.children) {
      const foundNode = this.findNodeById(id, child)

      if (foundNode) {
        return foundNode
      }
    }

    return null
  }

  addNode(parentId: string, newNode: IFileNode) {
    const parentNode = this.findNodeById(parentId)

    if (!parentNode) {
      throw new Error("La carpeta padre no existe")
    }

    if (parentNode.type === "file") {
      throw new Error("Un archivo no puede tener hijos")
    }

    parentNode.children.push(newNode)
  }

  static createNode(name: string, type: "folder" | "file", createdBy: string): IFileNode {
    return {
      id: crypto.randomUUID(),
      name,
      type,
      createdBy,
      children: [],
    }
  }

  toJSON() {
    return this.root
  }

  static fromJSON(data: IFileNode) {
    return new FileTree(data)
  }
}
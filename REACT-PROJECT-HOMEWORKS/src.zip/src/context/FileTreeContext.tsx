import { createContext, useContext, useEffect, useState, type ReactNode } from "react"
import { doc, getDoc, setDoc } from "firebase/firestore"
import { FileTree } from "../algorithms/FileTree"
import { db } from "../Firebase/config"
import { useAuth } from "../hooks/useAuth"
import type { IFileNode } from "../interfaces/IFileNode"

interface FileTreeContextType {
  tree: IFileNode
  loadingTree: boolean
  addNode: (parentId: string, name: string, type: "folder" | "file", createdBy: string) => Promise<void>
}

const FileTreeContext = createContext<FileTreeContextType | undefined>(undefined)

interface FileTreeProviderProps {
  children: ReactNode
}

const initialTree = new FileTree().toJSON()

export function FileTreeProvider({ children }: FileTreeProviderProps) {
  const { user } = useAuth()
  const [tree, setTree] = useState<IFileNode>(initialTree)
  const [loadingTree, setLoadingTree] = useState(true)

  useEffect(() => {
    async function loadTree() {
      if (!user) {
        setTree(initialTree)
        setLoadingTree(false)
        return
      }

      try {
        setLoadingTree(true)

        const treeRef = doc(db, "fileTrees", user.uid)
        const treeSnapshot = await getDoc(treeRef)

        if (treeSnapshot.exists()) {
          const data = treeSnapshot.data()
          setTree(data.tree)
        } else {
          await setDoc(treeRef, { tree: initialTree })
          setTree(initialTree)
        }
      } catch (error) {
        console.error("Error al cargar el árbol:", error)
      } finally {
        setLoadingTree(false)
      }
    }

    loadTree()
  }, [user])

  async function addNode(
    parentId: string,
    name: string,
    type: "folder" | "file",
    createdBy: string
  ) {
    if (!user) return

    const fileTree = FileTree.fromJSON(tree)
    const newNode = FileTree.createNode(name, type, createdBy)

    fileTree.addNode(parentId, newNode)

    const updatedTree = fileTree.toJSON()

    setTree({ ...updatedTree })

    const treeRef = doc(db, "fileTrees", user.uid)
    await setDoc(treeRef, { tree: updatedTree })
  }

  return (
    <FileTreeContext.Provider value={{ tree, loadingTree, addNode }}>
      {children}
    </FileTreeContext.Provider>
  )
}

export function useFileTreeContext() {
  const context = useContext(FileTreeContext)

  if (!context) {
    throw new Error("useFileTreeContext debe usarse dentro de FileTreeProvider")
  }

  return context
}
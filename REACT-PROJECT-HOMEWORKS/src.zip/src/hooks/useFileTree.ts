import { useFileTreeContext } from "../context/FileTreeContext"

export function useFileTree() {
  return useFileTreeContext()
}